--
-- njouanla_backup20140323-235841.sql.gz


DROP TABLE IF EXISTS `developer`;
CREATE TABLE `developer` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

INSERT INTO `developer` VALUES ('18','nico','410ec15153a6dff0bed851467309bcbd','nn@ff.com');
INSERT INTO `developer` VALUES ('19','david','96a9302d2d44ddb693c254208ee5bd3e','toto@toto.com');
INSERT INTO `developer` VALUES ('45','elyas-bhy','c071bd38e4c31ed73ec02faa32b52e4a','foo@bar.com');
INSERT INTO `developer` VALUES ('46','zizou','1d905276ba402677154922ffdf6ef88f','bastien.dufau@etu.u-bordeaux1.');


DROP TABLE IF EXISTS `game`;
CREATE TABLE `game` (
  `id_game` int(11) NOT NULL auto_increment,
  `username` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `resume` varchar(200) NOT NULL,
  `filename` varchar(50) NOT NULL,
  `min_player` int(10) NOT NULL default '2',
  `max_player` int(10) NOT NULL default '2',
  `path` varchar(200) NOT NULL,
  `version` varchar(100) NOT NULL default '1.0',
  `image` varchar(200) NOT NULL default 'http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/gamesImages/Default/logo_home_page.png',
  PRIMARY KEY  (`id_game`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `game` VALUES ('16','elyas-bhy','PygmyTestBeta2','Magnificent description2','game.jar','1','2','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/files/PygmyTestBeta2/game.jar','12','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/gamesImages/Default/logo_home_page.png');
INSERT INTO `game` VALUES ('17','elyas-bhy','PygmyDelta','Foo','game.jar','1','2','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/files/PygmyDelta/game.jar','14','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/gamesImages/Default/logo_home_page.png');
INSERT INTO `game` VALUES ('25','david','MyChess','yet another chess','game.jar','2','2','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/files/MyChess/game.jar','1.4','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/gamesImages/Default/logo_home_page.png');
INSERT INTO `game` VALUES ('26','elyas-bhy','PygmyReflection','Overlap rules test','game.jar','1','2','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/files/PygmyReflection/game.jar','16','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/gamesImages/PygmyReflection/img.jpg');
INSERT INTO `game` VALUES ('27','elyas-bhy','PygmyClientDemo','Client demo app','game.jar','1','2','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/files/PygmyClientDemo/game.jar','1.3','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/gamesImages/PygmyClientDemo/img.jpg');
INSERT INTO `game` VALUES ('28','nico','u','u','game.jar','2','2','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/files/u/game.jar','1.9','http://nicolas.jouanlanne.emi.u-bordeaux1.fr/PygmyDeveloper/gamesImages/Default/logo_home_page.png');


DROP TABLE IF EXISTS `report`;
CREATE TABLE `report` (
  `id` int(11) NOT NULL auto_increment,
  `report` varchar(200) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `report` VALUES ('12','Offensive content','PygmyReflection');
INSERT INTO `report` VALUES ('11','Other','PygmyReflection');
